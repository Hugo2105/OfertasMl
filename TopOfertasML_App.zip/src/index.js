import React from 'react';
import ReactDOM from 'react-dom/client';
import ProdutosMeli from './ProdutosMeli';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ProdutosMeli />);
